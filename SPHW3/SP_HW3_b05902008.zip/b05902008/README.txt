compile
   $make all

run server
   $server [port] [time_log] 

file_reader
   basic CGI, with A provided as test file

sleeper
   sleep for ten seconds, required to have NONE provided as filename

INFO
   when info is requested, executed to send SIGUSR1 to server

**written and tested on OS X El Captain(ver 10.11.3), with safari as browser, not gauranteed to work on other systems**
